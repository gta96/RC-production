(() => {
  const button = document.querySelector('[data-menu-toggle]');
  const menu = document.querySelector('[data-mobile-nav]');
  if (button && menu) {
    button.addEventListener('click', () => {
      const open = button.getAttribute('aria-expanded') !== 'true';
      button.setAttribute('aria-expanded', String(open));
      button.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
      menu.classList.toggle('open', open);
    });
    menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      menu.classList.remove('open');
      button.setAttribute('aria-expanded', 'false');
      button.setAttribute('aria-label', 'Ouvrir le menu');
    }));
  }

  function loadProjects() {
    try {
      const data = JSON.parse(localStorage.getItem('rc_videos') || '[]');
      return Array.isArray(data) ? data.filter(item => item && typeof item === 'object') : [];
    } catch (_) { return []; }
  }
  const escapeText = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const categoryKey = value => {
    const category = String(value || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    if (category.includes('music') || category.includes('clip')) return 'clip';
    if (category.includes('commercial') || category.includes('spot') || category.includes('pub')) return 'spot';
    if (category.includes('document') || category.includes('short film')) return 'documentaire';
    if (category.includes('brand') || category.includes('reel')) return 'brand';
    return 'other';
  };
  const projects = loadProjects();
  document.querySelectorAll('[data-project-grid]').forEach(grid => {
    const items = grid.dataset.projectGrid === 'featured' ? projects.slice(0, 6) : projects;
    if (!items.length) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.innerHTML = '<strong>Portfolio en préparation</strong><br>Contactez le studio pour découvrir nos projets et préparer le vôtre.';
      grid.appendChild(empty);
      return;
    }
    items.forEach(item => {
      const card = document.createElement('a');
      card.className = 'card';
      card.dataset.projectCategory = categoryKey(item.category);
      card.href = `realisation.html?id=${encodeURIComponent(item.id || '')}`;
      const media = document.createElement('div');
      media.className = 'card-media';
      const image = document.createElement('img');
      image.src = item.thumb || 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=900&q=80';
      image.alt = item.title ? `Image du projet ${item.title}` : 'Image du projet audiovisuel';
      image.loading = 'lazy';
      image.onerror = () => { image.src = 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=900&q=80'; };
      media.appendChild(image);
      const body = document.createElement('div');
      body.className = 'card-body';
      body.innerHTML = `<p class="meta">${escapeText(item.category || 'Production audiovisuelle')} · ${escapeText(item.year || '')}</p><h3>${escapeText(item.title || 'Projet RC Prod Art')}</h3><p>${escapeText(item.client || 'RC Prod Art')}</p>`;
      card.append(media, body);
      grid.appendChild(card);
    });
  });

  document.querySelectorAll('[data-project-filter]').forEach(button => {
    button.addEventListener('click', () => {
      const filter = button.dataset.projectFilter;
      document.querySelectorAll('[data-project-filter]').forEach(candidate => {
        const active = candidate === button;
        candidate.classList.toggle('active', active);
        candidate.setAttribute('aria-pressed', String(active));
      });
      document.querySelectorAll('[data-filterable-projects]').forEach(grid => {
        const cards = [...grid.querySelectorAll('.card[data-project-category]')];
        let visible = 0;
        cards.forEach(card => {
          const show = filter === 'all' || card.dataset.projectCategory === filter;
          card.hidden = !show;
          if (show) visible += 1;
        });
        let emptyFilter = grid.querySelector('.filter-empty');
        if (!emptyFilter) {
          emptyFilter = document.createElement('div');
          emptyFilter.className = 'empty-state filter-empty';
          emptyFilter.textContent = 'Aucune réalisation disponible dans cette catégorie pour le moment.';
          grid.appendChild(emptyFilter);
        }
        emptyFilter.hidden = visible > 0 || cards.length === 0;
      });
    });
  });

  const detail = document.querySelector('[data-project-detail]');
  if (detail) {
    const params = new URLSearchParams(location.search);
    const found = projects.find(item => String(item.id || '') === params.get('id'));
    const title = document.querySelector('[data-detail-title]');
    const meta = document.querySelector('[data-detail-meta]');
    const player = document.querySelector('[data-detail-player]');
    if (found) {
      if (title) title.textContent = found.title || 'Projet RC Prod Art';
      if (meta) meta.textContent = [found.category, found.client, found.year].filter(Boolean).join(' · ');
      const url = safeEmbedUrl(found.embed);
      if (player && url) {
        const iframe = document.createElement('iframe');
        iframe.src = url;
        iframe.title = `Vidéo : ${found.title || 'Projet RC Prod Art'}`;
        iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
        iframe.allowFullscreen = true;
        player.appendChild(iframe);
      } else if (player) {
        player.textContent = 'La vidéo de ce projet sera bientôt disponible.';
        player.style.display = 'grid'; player.style.placeItems = 'center'; player.style.color = '#a4a19a';
      }
    } else {
      if (title) title.textContent = 'Projet introuvable';
      if (meta) meta.textContent = 'Consultez le portfolio ou contactez le studio.';
      if (player) player.remove();
    }
  }

  function safeEmbedUrl(raw) {
    try {
      const u = new URL(raw);
      if (u.protocol !== 'https:') return '';
      if (['youtube.com','www.youtube.com','m.youtube.com'].includes(u.hostname)) {
        if (u.pathname.startsWith('/embed/')) return u.href;
        const id = u.searchParams.get('v');
        return id ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}` : '';
      }
      if (u.hostname === 'youtu.be') return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(u.pathname.slice(1))}`;
      if (u.hostname === 'player.vimeo.com' && u.pathname.startsWith('/video/')) return u.href;
      if (u.hostname === 'vimeo.com') return `https://player.vimeo.com/video/${encodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || '')}`;
      return '';
    } catch (_) { return ''; }
  }
})();
